<?php

include_once get_template_directory().'/framework/modules/shortcodes/info-card-slider/info-card-slider.php';
include_once get_template_directory().'/framework/modules/shortcodes/info-card-slider/info-card-slider-item.php';