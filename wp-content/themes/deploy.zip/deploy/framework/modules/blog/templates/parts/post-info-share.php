<div class ="mkdf-blog-share mkdf-post-info-item">
	<?php echo deploy_mikado_get_social_share_html(array('type' => 'dropdown')); ?>
</div>