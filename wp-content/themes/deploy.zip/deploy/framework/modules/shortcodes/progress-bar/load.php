<?php

include_once get_template_directory().'/framework/modules/shortcodes/progress-bar/progress-bar.php';
include_once get_template_directory().'/framework/modules/shortcodes/progress-bar/custom-styles/progress-bar.php';

