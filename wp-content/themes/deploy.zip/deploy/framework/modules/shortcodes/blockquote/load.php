<?php

include_once get_template_directory().'/framework/modules/shortcodes/blockquote/options-map/map.php';
include_once get_template_directory().'/framework/modules/shortcodes/blockquote/blockquote.php';
include_once get_template_directory().'/framework/modules/shortcodes/blockquote/custom-styles/blockquote.php';