<?php

include_once get_template_directory().'/framework/modules/search/options-map/map.php';
include_once get_template_directory().'/framework/modules/search/search-functions.php';
include_once get_template_directory().'/framework/modules/search/template-hooks.php';
include_once get_template_directory().'/framework/modules/search/custom-styles/search.php';