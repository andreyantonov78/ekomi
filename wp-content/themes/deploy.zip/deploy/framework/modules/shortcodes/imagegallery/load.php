<?php

include_once get_template_directory().'/framework/modules/shortcodes/imagegallery/image-gallery.php';