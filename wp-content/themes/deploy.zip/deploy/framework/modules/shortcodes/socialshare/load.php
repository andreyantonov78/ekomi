<?php

include_once get_template_directory().'/framework/modules/shortcodes/socialshare/social-share-functions.php';
include_once get_template_directory().'/framework/modules/shortcodes/socialshare/social-share.php';
include_once get_template_directory().'/framework/modules/shortcodes/socialshare/custom-styles/social-share.php';