<?php

include get_template_directory().'/framework/modules/shortcodes/shape-separator/shape-separator.php';