<?php

include_once get_template_directory().'/framework/modules/sidearea/options-map/map.php';
include_once get_template_directory().'/framework/modules/sidearea/sidearea-functions.php';
include_once get_template_directory().'/framework/modules/sidearea/custom-styles/sidearea.php';