<div class="mkdf-section-title-holder">
	<h2 <?php deploy_mikado_class_attribute($section_title_classes); ?> <?php deploy_mikado_inline_style($section_title_styles); ?>><?php echo esc_html($title); ?></h2>
</div>