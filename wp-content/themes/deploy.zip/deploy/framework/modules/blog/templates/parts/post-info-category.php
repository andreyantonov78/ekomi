<div class="mkdf-post-info-category mkdf-post-info-item">
	<span class="mkdf-blog-category-icon">
		<?php echo deploy_mikado_icon_collections()->renderIcon('icon-folder-alt', 'simple_line_icons'); ?>
	</span>
	<?php esc_html_e('in ', 'deploy'); ?><?php the_category(', '); ?>
</div>