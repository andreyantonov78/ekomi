<?php

include_once get_template_directory().'/framework/modules/shortcodes/team/options-map/map.php';
include_once get_template_directory().'/framework/modules/shortcodes/team/team.php';
include_once get_template_directory().'/framework/modules/shortcodes/team/custom-styles/team.php';