<?php
include_once get_template_directory().'/framework/modules/shortcodes/accordions/accordion.php';
include_once get_template_directory().'/framework/modules/shortcodes/accordions/accordion-tab.php';
include_once get_template_directory().'/framework/modules/shortcodes/accordions/custom-styles/custom-styles.php';
include_once get_template_directory().'/framework/modules/shortcodes/accordions/options-map/map.php';
