<?php

//Get search HTML
add_action('deploy_mikado_before_page_header', 'deploy_mikado_get_search', 9);