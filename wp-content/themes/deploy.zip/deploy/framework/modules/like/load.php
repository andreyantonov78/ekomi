<?php

include_once get_template_directory().'/framework/modules/like/like.php';
include_once get_template_directory().'/framework/modules/like/like-functions.php';