<?php

include_once get_template_directory().'/framework/modules/footer/options-map/map.php';
include_once get_template_directory().'/framework/modules/footer/functions.php';
include_once get_template_directory().'/framework/modules/footer/template-functions.php';
