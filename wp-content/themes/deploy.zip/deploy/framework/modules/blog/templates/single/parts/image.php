<?php if ( has_post_thumbnail() ) { ?>
	<div class="mkdf-post-image">
			<?php the_post_thumbnail('full'); ?>
	</div>
<?php } ?>