<?php

include_once get_template_directory().'/framework/modules/shortcodes/message/message.php';
include_once get_template_directory().'/framework/modules/shortcodes/message/custom-styles/message.php';