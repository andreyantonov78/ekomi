<?php

include_once get_template_directory().'/framework/modules/shortcodes/icon/icon.php';