<div class="mkdf-blog-like mkdf-post-info-item">
	<?php if( function_exists('deploy_mikado_get_like') ) deploy_mikado_get_like(); ?>
</div>