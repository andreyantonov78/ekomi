<div class="mkdf-icon-slide-content">
    <?php echo do_shortcode($content); ?>
</div>