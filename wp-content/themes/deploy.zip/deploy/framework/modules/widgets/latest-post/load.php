<?php

require_once get_template_directory().'/framework/modules/widgets/latest-post//latest-posts.php';