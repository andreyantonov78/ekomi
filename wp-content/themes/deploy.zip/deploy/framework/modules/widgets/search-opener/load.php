<?php

require_once get_template_directory().'/framework/modules/widgets/search-opener/search-opener.php';
