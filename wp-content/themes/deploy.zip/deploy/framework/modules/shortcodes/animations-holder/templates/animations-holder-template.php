<div <?php deploy_mikado_class_attribute($class); ?> <?php echo deploy_mikado_get_inline_attrs($data); ?>>
	<div <?php deploy_mikado_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>