<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to deploy_mikado_style_dynamic hook
 */

//if (!function_exists('mkdf_counter_style')) {
//
//	function mkdf_counter_style()
//	{
//
//		if (deploy_mikado_options()->getOptionValue('option_value') !== '') {
//			echo deploy_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => deploy_mikado_filter_px(deploy_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('deploy_mikado_style_dynamic', 'mkdf_counter_style');
//
//}

?>