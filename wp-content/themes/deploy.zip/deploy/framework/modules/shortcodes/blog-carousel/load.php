<?php

include_once get_template_directory().'/framework/modules/shortcodes/blog-carousel/blog-carousel.php';