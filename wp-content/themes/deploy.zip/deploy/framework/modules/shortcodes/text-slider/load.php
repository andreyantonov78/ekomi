<?php
include_once get_template_directory().'/framework/modules/shortcodes/text-slider/text-slider-holder.php';
include_once get_template_directory().'/framework/modules/shortcodes/text-slider/text-slider-item.php';