<?php

include_once get_template_directory().'/framework/modules/shortcodes/twitter-slider/twitter-slider.php';