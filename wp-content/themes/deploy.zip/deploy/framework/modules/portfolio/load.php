<?php

include_once get_template_directory().'/framework/modules/portfolio/options-map/map.php';
include_once get_template_directory().'/framework/modules/portfolio/portfolio-functions.php';
include_once get_template_directory().'/framework/modules/portfolio/custom-styles/portfolio.php';