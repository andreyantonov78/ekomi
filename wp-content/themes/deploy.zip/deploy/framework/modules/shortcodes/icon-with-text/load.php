<?php

include_once get_template_directory().'/framework/modules/shortcodes/icon-with-text/icon-with-text.php';