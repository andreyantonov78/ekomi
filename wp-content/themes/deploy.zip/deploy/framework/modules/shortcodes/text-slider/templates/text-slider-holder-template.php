<div <?php deploy_mikado_class_attribute($text_slider_classes)?>>
    <div <?php deploy_mikado_class_attribute($text_slider_navigation)?>>
        <?php echo do_shortcode($content); ?>
    </div>
</div>