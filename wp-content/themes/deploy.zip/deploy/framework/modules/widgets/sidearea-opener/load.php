<?php

require_once get_template_directory().'/framework/modules/widgets/sidearea-opener/side-area-opener.php';