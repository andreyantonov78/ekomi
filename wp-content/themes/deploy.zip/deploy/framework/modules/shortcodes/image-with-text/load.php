<?php

include_once get_template_directory().'/framework/modules/shortcodes/image-with-text/image-with-text.php';