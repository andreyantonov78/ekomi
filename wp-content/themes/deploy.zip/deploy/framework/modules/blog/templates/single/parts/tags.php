<div class="mkdf-single-tags-holder">
	<div class="mkdf-tags">
		<?php the_tags('', '', ''); ?>
	</div>
</div>