<?php

include_once get_template_directory().'/framework/modules/blog/options-map/map.php';
include_once get_template_directory().'/framework/modules/blog/blog-functions.php';