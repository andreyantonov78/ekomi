<?php

include_once get_template_directory().'/framework/modules/shortcodes/separator/separator.php';
include_once get_template_directory().'/framework/modules/shortcodes/separator/custom-styles/separator.php';

