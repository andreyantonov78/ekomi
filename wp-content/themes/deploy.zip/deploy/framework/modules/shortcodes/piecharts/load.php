<?php

//Pie Chart Pie
include_once get_template_directory().'/framework/modules/shortcodes/piecharts/piechartpie/load.php';

//Pie Chart Doughnut
include_once get_template_directory().'/framework/modules/shortcodes/piecharts/piechartdoughnut/load.php';

//Pie Chart With Icon
include_once get_template_directory().'/framework/modules/shortcodes/piecharts/piechartwithicon/load.php';

//Pie Chart Basic
include_once get_template_directory().'/framework/modules/shortcodes/piecharts/piechartbasic/load.php';