<?php

include_once get_template_directory().'/framework/modules/shortcodes/icon-slider/icon-slider.php';
include_once get_template_directory().'/framework/modules/shortcodes/icon-slider/icon-slider-item.php';