<div class="mkdf-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="mkdf-separator" <?php echo deploy_mikado_get_inline_style($separator_style); ?>></div>
</div>
