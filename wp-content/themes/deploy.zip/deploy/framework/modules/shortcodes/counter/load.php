<?php

include_once get_template_directory().'/framework/modules/shortcodes/counter/counter.php';
include_once get_template_directory().'/framework/modules/shortcodes/counter/custom-styles/counter.php';