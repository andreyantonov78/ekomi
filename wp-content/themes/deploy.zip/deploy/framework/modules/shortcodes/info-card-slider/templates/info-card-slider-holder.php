<div <?php deploy_mikado_class_attribute($holder_classes); ?>>
    <div class="mkdf-info-card-slider-holder">
        <?php echo do_shortcode($content); ?>
    </div>
</div>