<?php

include_once get_template_directory().'/framework/modules/layerslider/layer-slider-config.php';
