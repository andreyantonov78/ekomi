<div class="mkdf-social-share-holder mkdf-list">
	<ul>
		<?php foreach ($networks as $net) {
			print $net;
		} ?>
	</ul>
</div>