 <div class="mkdf-text-slider-item"><?php echo do_shortcode($content); ?></div>
