<?php
require_once get_template_directory().'/framework/modules/shortcodes/tabs/tabs.php';
require_once get_template_directory().'/framework/modules/shortcodes/tabs/tab.php';
require_once get_template_directory().'/framework/modules/shortcodes/tabs/options-map/map.php';
