<?php

include_once get_template_directory().'/framework/modules/title/options-map/map.php';
include_once get_template_directory().'/framework/modules/title/filter-functions.php';
include_once get_template_directory().'/framework/modules/title/title-functions.php';
include_once get_template_directory().'/framework/modules/title/custom-styles/title.php';