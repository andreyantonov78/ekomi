<?php

if (deploy_mikado_visual_composer_installed()) {
	include_once get_template_directory().'/framework/modules/visualcomposer/visual-composer-functions.php';
	include_once get_template_directory().'/framework/modules/visualcomposer/visual-composer-config.php';
}