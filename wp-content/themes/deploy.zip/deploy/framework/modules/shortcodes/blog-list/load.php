<?php

include_once get_template_directory().'/framework/modules/shortcodes/blog-list/blog-list.php';
include_once get_template_directory().'/framework/modules/shortcodes/blog-list/custom-styles/blog-list.php';