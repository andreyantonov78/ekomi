<?php

include_once get_template_directory().'/framework/modules/shortcodes/calltoaction/options-map/map.php';
include_once get_template_directory().'/framework/modules/shortcodes/calltoaction/call-to-action.php';
include_once get_template_directory().'/framework/modules/shortcodes/calltoaction/custom-styles/call-to-action.php';